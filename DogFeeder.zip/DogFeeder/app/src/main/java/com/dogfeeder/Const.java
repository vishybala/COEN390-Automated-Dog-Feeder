package com.dogfeeder;

public class Const {

    public static Dog dog;

    //Meal Times
    public static final String MEAL_1_TIME = "09:00";
    public static final String MEAL_2_TIME = "12:00";
    public static final String MEAL_3_TIME = "15:00";
    public static final String MEAL_4_TIME = "20:00";

}
